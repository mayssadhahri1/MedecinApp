package com.example.medecinapp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.medecinapp.DBHelper;
import com.example.medecinapp.R;

public class EditPatientActivity extends AppCompatActivity {

    EditText nomInput, prenomInput, dateInput, emailInput, telInput, adresseInput;
    Button updateBtn, deleteBtn, ordonnanceBtn, showOrdonnancesBtn;
    DBHelper dbHelper;
    int id;
    String patientNom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_patient);

        dbHelper = new DBHelper(this);

        nomInput = findViewById(R.id.nomInput);
        prenomInput = findViewById(R.id.prenomInput);
        dateInput = findViewById(R.id.dateInput);
        emailInput = findViewById(R.id.emailInput);
        telInput = findViewById(R.id.telInput);
        adresseInput = findViewById(R.id.adresseInput);

        updateBtn = findViewById(R.id.updatePatientBtn);
        deleteBtn = findViewById(R.id.deletePatientBtn);
        ordonnanceBtn = findViewById(R.id.ordonnanceBtn);
        showOrdonnancesBtn = findViewById(R.id.showOrdonnancesBtn);

        id = getIntent().getIntExtra("id", -1);
        patientNom = getIntent().getStringExtra("nom");

        nomInput.setText(patientNom);
        prenomInput.setText(getIntent().getStringExtra("prenom"));
        dateInput.setText(getIntent().getStringExtra("date_naissance"));
        emailInput.setText(getIntent().getStringExtra("email"));
        telInput.setText(getIntent().getStringExtra("telephone"));
        adresseInput.setText(getIntent().getStringExtra("adresse"));

        updateBtn.setOnClickListener(v -> updatePatient());
        deleteBtn.setOnClickListener(v -> deletePatient());
        ordonnanceBtn.setOnClickListener(v -> openAddOrdonnance());
        showOrdonnancesBtn.setOnClickListener(v -> openShowOrdonnances());
    }

    private void updatePatient() {
        String nom = nomInput.getText().toString();
        String prenom = prenomInput.getText().toString();
        String dateNaissance = dateInput.getText().toString();
        String email = emailInput.getText().toString();
        String telephone = telInput.getText().toString();
        String adresse = adresseInput.getText().toString();

        boolean success = dbHelper.updatePatient(id, nom, prenom, dateNaissance, email, telephone, adresse);

        if (success) {
            Toast.makeText(this, "Le patient " + nom + " a été modifié avec succès !", Toast.LENGTH_LONG).show();
            finish();
        } else {
            Toast.makeText(this, "Erreur lors de la modification de " + nom, Toast.LENGTH_SHORT).show();
        }
    }

    private void deletePatient() {
        boolean success = dbHelper.deletePatient(id);

        if (success) {
            Toast.makeText(this, "Le patient " + patientNom + " a été supprimé avec succès !", Toast.LENGTH_LONG).show();
            finish();
        } else {
            Toast.makeText(this, "Erreur lors de la suppression de " + patientNom, Toast.LENGTH_SHORT).show();
        }
    }

    private void openAddOrdonnance() {
        Intent intent = new Intent(EditPatientActivity.this, AddOrdonnanceActivity.class);
        intent.putExtra("patient_id", id);
        intent.putExtra("patient_nom", patientNom);
        startActivity(intent);
    }

    private void openShowOrdonnances() {
        Intent intent = new Intent(EditPatientActivity.this, ShowOrdonnancesActivity.class);
        intent.putExtra("patient_id", id);
        startActivity(intent);
    }
}
