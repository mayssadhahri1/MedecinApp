package com.example.medecinapp.activities;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.medecinapp.DBHelper;
import com.example.medecinapp.R;
import com.example.medecinapp.adapters.OrdonnanceAdapter;

import java.util.ArrayList;
import java.util.HashMap;

public class ShowOrdonnancesActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private DBHelper dbHelper;
    private int patientId;
    private OrdonnanceAdapter adapter;
    private ArrayList<HashMap<String, String>> ordonnancesList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_ordonnances);

        recyclerView = findViewById(R.id.ordonnancesRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        dbHelper = new DBHelper(this);
        ordonnancesList = new ArrayList<>();

        patientId = getIntent().getIntExtra("patient_id", -1);
        if (patientId == -1) {
            Toast.makeText(this, "ID du patient invalide", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        loadOrdonnances();
    }

    private void loadOrdonnances() {
        Cursor cursor = dbHelper.getOrdonnancesByPatient(patientId);
        if (cursor != null && cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                HashMap<String, String> ordonnance = new HashMap<>();
                ordonnance.put("date", cursor.getString(cursor.getColumnIndexOrThrow("date")));
                ordonnance.put("medicaments", cursor.getString(cursor.getColumnIndexOrThrow("medicaments")));
                ordonnance.put("instructions", cursor.getString(cursor.getColumnIndexOrThrow("instructions")));
                ordonnancesList.add(ordonnance);
            }
            adapter = new OrdonnanceAdapter(ordonnancesList);
            recyclerView.setAdapter(adapter);
        } else {
            Toast.makeText(this, "Aucune ordonnance trouvée", Toast.LENGTH_SHORT).show();
        }
        if (cursor != null) cursor.close();
    }
}
