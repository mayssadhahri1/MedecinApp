package com.example.medecinapp.activities;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.medecinapp.DBHelper;
import com.example.medecinapp.R;

public class AddPatientActivity extends AppCompatActivity {

    EditText nomInput, prenomInput, dateNaissanceInput, emailInput, telephoneInput, adresseInput;
    Button saveBtn;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_patient);

        nomInput = findViewById(R.id.nomInput);
        prenomInput = findViewById(R.id.prenomInput);
        dateNaissanceInput = findViewById(R.id.dateNaissanceInput);
        emailInput = findViewById(R.id.emailInput);
        telephoneInput = findViewById(R.id.telephoneInput);
        adresseInput = findViewById(R.id.adresseInput);
        saveBtn = findViewById(R.id.saveBtn);

        dbHelper = new DBHelper(this);

        saveBtn.setOnClickListener(v -> savePatient());
    }

    private void savePatient() {
        String nom = nomInput.getText().toString().trim();
        String prenom = prenomInput.getText().toString().trim();
        String dateNaissance = dateNaissanceInput.getText().toString().trim();
        String email = emailInput.getText().toString().trim();
        String telephone = telephoneInput.getText().toString().trim();
        String adresse = adresseInput.getText().toString().trim();

        if(nom.isEmpty() || prenom.isEmpty() || email.isEmpty()){
            Toast.makeText(this, "Veuillez remplir les champs obligatoires", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nom", nom);
        values.put("prenom", prenom);
        values.put("date_naissance", dateNaissance);
        values.put("email", email);
        values.put("telephone", telephone);
        values.put("adresse", adresse);

        long result = db.insert("patient", null, values);
        if(result != -1){
            Toast.makeText(this, "Patient ajouté avec succès", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Erreur lors de l'ajout", Toast.LENGTH_SHORT).show();
        }
    }
}
