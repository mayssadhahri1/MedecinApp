package com.example.medecinapp.activities;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.medecinapp.DBHelper;
import com.example.medecinapp.R;
import com.example.medecinapp.adapters.PatientAdapter;
import com.example.medecinapp.models.Patient;

import java.util.ArrayList;

public class PatientsActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    Button addPatientBtn;
    EditText searchPatient;
    DBHelper dbHelper;
    ArrayList<Patient> patientList;
    PatientAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patients);

        // Initialisation des vues
        recyclerView = findViewById(R.id.patientRecyclerView);
        addPatientBtn = findViewById(R.id.addPatientBtn);
        searchPatient = findViewById(R.id.searchPatient);

        dbHelper = new DBHelper(this);
        patientList = new ArrayList<>();
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        loadPatients();

        // Ajouter patient
        addPatientBtn.setOnClickListener(v -> {
            startActivity(new Intent(PatientsActivity.this, AddPatientActivity.class));
        });

        // Filtrage en temps réel
        searchPatient.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (adapter != null) {
                    adapter.getFilter().filter(s);
                }
            }

            @Override
            public void afterTextChanged(Editable s) { }
        });
    }

    private void loadPatients() {
        patientList.clear();
        Cursor cursor = dbHelper.getAllPatients();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String nom = cursor.getString(cursor.getColumnIndexOrThrow("nom"));
                String prenom = cursor.getString(cursor.getColumnIndexOrThrow("prenom"));
                String dateNaissance = cursor.getString(cursor.getColumnIndexOrThrow("date_naissance"));
                String email = cursor.getString(cursor.getColumnIndexOrThrow("email"));
                String telephone = cursor.getString(cursor.getColumnIndexOrThrow("telephone"));
                String adresse = cursor.getString(cursor.getColumnIndexOrThrow("adresse"));

                patientList.add(new Patient(id, nom, prenom, dateNaissance, email, telephone, adresse));

            } while (cursor.moveToNext());
            cursor.close();
        }

        if (adapter == null) {
            adapter = new PatientAdapter(this, patientList);
            recyclerView.setAdapter(adapter);
        } else {
            adapter.notifyDataSetChanged();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadPatients();
    }
}
