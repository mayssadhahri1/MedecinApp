package com.example.medecinapp.activities;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.medecinapp.DBHelper;
import com.example.medecinapp.R;

public class AddOrdonnanceActivity extends AppCompatActivity {

    EditText medicamentsInput, instructionsInput;
    Button saveBtn;
    DBHelper dbHelper;
    int patientId;
    String patientNom;
    int medecinId = 1; // Remplace par l'ID du médecin connecté si tu gères l'authentification

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_ordonnance);

        dbHelper = new DBHelper(this);

        medicamentsInput = findViewById(R.id.medicamentsInput);
        instructionsInput = findViewById(R.id.instructionsInput);
        saveBtn = findViewById(R.id.saveOrdonnanceBtn);

        // Récupérer l'ID et le nom du patient depuis l'intent
        patientId = getIntent().getIntExtra("patient_id", -1);
        patientNom = getIntent().getStringExtra("patient_nom");

        if (patientId == -1) {
            Toast.makeText(this, "Erreur : ID du patient invalide", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        saveBtn.setOnClickListener(v -> addOrdonnance());
    }

    private void addOrdonnance() {
        String medicaments = medicamentsInput.getText().toString().trim();
        String instructions = instructionsInput.getText().toString().trim();

        Log.d("AddOrdonnance", "PatientID=" + patientId + ", Medicaments=" + medicaments + ", Instructions=" + instructions);

        if (medicaments.isEmpty() || instructions.isEmpty()) {
            Toast.makeText(this, "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            long result = dbHelper.addOrdonnance(
                    patientId,
                    medecinId,
                    java.time.LocalDate.now().toString(),
                    medicaments,
                    instructions
            );

            Log.d("AddOrdonnance", "Result=" + result);

            if (result != -1) {
                Toast.makeText(this, "Ordonnance ajoutée pour " + patientNom, Toast.LENGTH_LONG).show();
                finish();
            } else {
                Toast.makeText(this, "Erreur lors de l'ajout de l'ordonnance", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e("AddOrdonnanceActivity", "Erreur addOrdonnance", e);
            Toast.makeText(this, "Erreur : " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
