package com.example.medecinapp.adapters;

import android.content.Context;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.medecinapp.R;
import com.example.medecinapp.models.Patient;

import java.util.HashSet;
import java.util.List;

public class PatientSelectAdapter extends RecyclerView.Adapter<PatientSelectAdapter.PatientViewHolder> {

    public interface OnPatientSelectedListener {
        void onPatientSelected(Patient patient);
        void onPatientDeselected(Patient patient);
    }

    private Context context;
    private List<Patient> patientList;
    private OnPatientSelectedListener listener;
    private HashSet<Integer> selectedPatientIds = new HashSet<>();

    public PatientSelectAdapter(Context context, List<Patient> patientList, OnPatientSelectedListener listener) {
        this.context = context;
        this.patientList = patientList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public PatientViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_patient_card, parent, false);
        return new PatientViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PatientViewHolder holder, int position) {
        Patient patient = patientList.get(position);
        holder.patientName.setText(patient.getNom() + " " + patient.getPrenom());
        holder.patientPhone.setText(patient.getTelephone());

        // Définir couleur de fond selon sélection
        if (selectedPatientIds.contains(patient.getId())) {
            holder.card.setCardBackgroundColor(ContextCompat.getColor(context, R.color.pastelGreen));
        } else {
            holder.card.setCardBackgroundColor(ContextCompat.getColor(context, R.color.cardBackground));
        }

        holder.card.setOnClickListener(v -> {
            if (selectedPatientIds.contains(patient.getId())) {
                // Désélectionner
                selectedPatientIds.remove(patient.getId());
                holder.card.setCardBackgroundColor(ContextCompat.getColor(context, R.color.cardBackground));
                listener.onPatientDeselected(patient);
            } else {
                // Sélectionner
                selectedPatientIds.clear(); // sélection unique
                selectedPatientIds.add(patient.getId());
                notifyDataSetChanged(); // mettre à jour tous les items
                listener.onPatientSelected(patient);

                // Effet visuel clignotant
                holder.card.setCardBackgroundColor(ContextCompat.getColor(context, R.color.pastelBlue));
                new Handler().postDelayed(() -> {
                    holder.card.setCardBackgroundColor(ContextCompat.getColor(context, R.color.pastelGreen));
                }, 200);
            }
        });
    }

    @Override
    public int getItemCount() {
        return patientList.size();
    }
    public void setSelectedPatientId(int id){
        selectedPatientIds.clear();
        if(id != -1) selectedPatientIds.add(id);
        notifyDataSetChanged();
    }

    static class PatientViewHolder extends RecyclerView.ViewHolder {
        CardView card;
        TextView patientName, patientPhone;

        public PatientViewHolder(@NonNull View itemView) {
            super(itemView);
            card = itemView.findViewById(R.id.patientCard);
            patientName = itemView.findViewById(R.id.patientName);
            patientPhone = itemView.findViewById(R.id.patientPhone);
        }
    }
}
