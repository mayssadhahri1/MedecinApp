package com.example.medecinapp.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.medecinapp.R;

import java.util.ArrayList;
import java.util.HashMap;

public class OrdonnanceAdapter extends RecyclerView.Adapter<OrdonnanceAdapter.ViewHolder> {

    private ArrayList<HashMap<String, String>> ordonnancesList;

    public OrdonnanceAdapter(ArrayList<HashMap<String, String>> list) {
        this.ordonnancesList = list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_ordonnance, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        HashMap<String, String> ordonnance = ordonnancesList.get(position);
        holder.tvDate.setText("Date: " + ordonnance.get("date"));
        holder.tvMedicaments.setText("Médicaments: " + ordonnance.get("medicaments"));
        holder.tvInstructions.setText("Instructions: " + ordonnance.get("instructions"));
    }

    @Override
    public int getItemCount() {
        return ordonnancesList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvDate, tvMedicaments, tvInstructions;

        public ViewHolder(View itemView) {
            super(itemView);
            tvDate = itemView.findViewById(R.id.tvOrdonnanceDate);
            tvMedicaments = itemView.findViewById(R.id.tvOrdonnanceMedicaments);
            tvInstructions = itemView.findViewById(R.id.tvOrdonnanceInstructions);
        }
    }
}
