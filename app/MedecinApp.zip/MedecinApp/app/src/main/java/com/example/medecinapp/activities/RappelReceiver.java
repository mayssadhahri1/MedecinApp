package com.example.medecinapp.activities;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;

public class RappelReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context ctx, Intent i) {

        NotificationManager nm = (NotificationManager)
                ctx.getSystemService(Context.NOTIFICATION_SERVICE);

        String id = "rv_channel";

        if(android.os.Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch =
                    new NotificationChannel(id, "Rappel Rendez-vous",
                            NotificationManager.IMPORTANCE_HIGH);
            nm.createNotificationChannel(ch);
        }

        NotificationCompat.Builder b =
                new NotificationCompat.Builder(ctx, id)
                        .setContentTitle("Rappel Rendez-vous")
                        .setContentText("Vous avez un rendez-vous aujourd’hui")
                        .setSmallIcon(android.R.drawable.ic_dialog_info);

        nm.notify(1, b.build());
    }
}