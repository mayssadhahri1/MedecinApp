package com.example.medecinapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.medecinapp.models.RendezVous;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 2;
    private static final String DATABASE_NAME = "medecin.db";
    private static final String TAG = "DBHelper";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Table Medecin
        db.execSQL("CREATE TABLE IF NOT EXISTS medecin(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "nom TEXT, " +
                "email TEXT UNIQUE, " +
                "mot_de_passe TEXT, " +
                "specialite TEXT, " +
                "telephone TEXT)");

        // Table Patient
        db.execSQL("CREATE TABLE IF NOT EXISTS patient(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "nom TEXT, " +
                "prenom TEXT, " +
                "date_naissance TEXT, " +
                "email TEXT, " +
                "telephone TEXT, " +
                "adresse TEXT)");

        // Table Rendez-vous
        db.execSQL("CREATE TABLE IF NOT EXISTS rendezvous(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "patient_id INTEGER, " +
                "medecin_id INTEGER, " +
                "date TEXT, " +
                "statut TEXT, " +
                "rappel INTEGER DEFAULT 1, " +
                "FOREIGN KEY(patient_id) REFERENCES patient(id), " +
                "FOREIGN KEY(medecin_id) REFERENCES medecin(id))");

        // Table Ordonnance
        db.execSQL("CREATE TABLE IF NOT EXISTS ordonnance(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "patient_id INTEGER, " +
                "medecin_id INTEGER, " +
                "date TEXT, " +
                "medicaments TEXT, " +
                "instructions TEXT, " +
                "FOREIGN KEY(patient_id) REFERENCES patient(id), " +
                "FOREIGN KEY(medecin_id) REFERENCES medecin(id))");

        Log.d(TAG, "Base de données créée avec succès");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS ordonnance");
        db.execSQL("DROP TABLE IF EXISTS rendezvous");
        db.execSQL("DROP TABLE IF EXISTS patient");
        db.execSQL("DROP TABLE IF EXISTS medecin");
        onCreate(db);
        Log.d(TAG, "Base de données mise à jour");
    }

    // ====================== ORDONNANCE ======================
    public Cursor getOrdonnancesByPatient(int patientId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery(
                "SELECT id AS _id, patient_id, medecin_id, date, medicaments, instructions " +
                        "FROM ordonnance WHERE patient_id=? ORDER BY date DESC",
                new String[]{String.valueOf(patientId)});
    }

    public long addOrdonnance(int patientId, int medecinId, String date, String medicaments, String instructions) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("patient_id", patientId);
        cv.put("medecin_id", medecinId);
        cv.put("date", date);
        cv.put("medicaments", medicaments);
        cv.put("instructions", instructions);
        return db.insert("ordonnance", null, cv);
    }

    public boolean updateOrdonnance(int id, int patientId, int medecinId, String date, String medicaments, String instructions) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("patient_id", patientId);
        values.put("medecin_id", medecinId);
        values.put("date", date);
        values.put("medicaments", medicaments);
        values.put("instructions", instructions);
        return db.update("ordonnance", values, "id=?", new String[]{String.valueOf(id)}) > 0;
    }

    public boolean deleteOrdonnance(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("ordonnance", "id=?", new String[]{String.valueOf(id)}) > 0;
    }

    public Cursor getAllOrdonnances() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query("ordonnance", null, null, null, null, null, "date DESC");
    }

    // ====================== MEDECIN ======================
    public long addMedecin(String nom, String email, String motDePasse, String specialite, String telephone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nom", nom);
        values.put("email", email);
        values.put("mot_de_passe", motDePasse);
        values.put("specialite", specialite);
        values.put("telephone", telephone);
        return db.insert("medecin", null, values);
    }

    public boolean checkMedecin(String email, String hashedPassword) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM medecin WHERE email=? AND mot_de_passe=?",
                new String[]{email, hashedPassword});
        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;
    }

    public Cursor getAllMedecins() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query("medecin", null, null, null, null, null, "nom ASC");
    }

    // ====================== PATIENT ======================
    public long addPatient(String nom, String prenom, String dateNaissance, String email, String telephone, String adresse) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nom", nom);
        values.put("prenom", prenom);
        values.put("date_naissance", dateNaissance);
        values.put("email", email);
        values.put("telephone", telephone);
        values.put("adresse", adresse);
        return db.insert("patient", null, values);
    }

    public boolean updatePatient(int id, String nom, String prenom, String dateNaissance, String email, String telephone, String adresse) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nom", nom);
        values.put("prenom", prenom);
        values.put("date_naissance", dateNaissance);
        values.put("email", email);
        values.put("telephone", telephone);
        values.put("adresse", adresse);
        return db.update("patient", values, "id=?", new String[]{String.valueOf(id)}) > 0;
    }

    public boolean deletePatient(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("patient", "id=?", new String[]{String.valueOf(id)}) > 0;
    }

    public Cursor getAllPatients() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query("patient", null, null, null, null, null, "nom ASC");
    }


    // Vérifie si un patient a déjà un rendez-vous ce jour-là

    // Vérifie si un créneau horaire est déjà pris
    public boolean isTimeSlotTaken(String dateTime) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM rendezvous WHERE date=?", new String[]{dateTime});
        boolean taken = (cursor.getCount() > 0);
        cursor.close();
        return taken;
    }


    // ====================== RENDEZ-VOUS ======================
    public boolean addRendezVous(RendezVous r) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("patient_id", r.getPatientId());
        cv.put("medecin_id", r.getMedecinId());
        cv.put("date", r.getDate());
        cv.put("statut", r.getStatut());
        cv.put("rappel", r.getRappel());
        long result = db.insert("rendezvous", null, cv);
        Log.d(TAG, "addRendezVous: patientId=" + r.getPatientId() + " | date=" + r.getDate() + " | result=" + result);
        return result != -1;
    }

    public boolean updateRendezVous(RendezVous r) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("date", r.getDate());
        cv.put("statut", r.getStatut());
        cv.put("rappel", r.getRappel());
        boolean updated = db.update("rendezvous", cv, "id=?", new String[]{String.valueOf(r.getId())}) > 0;
        Log.d(TAG, "updateRendezVous: id=" + r.getId() + " | date=" + r.getDate() + " | updated=" + updated);
        return updated;
    }

    public boolean deleteRendezVous(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        boolean deleted = db.delete("rendezvous", "id=?", new String[]{String.valueOf(id)}) > 0;
        Log.d(TAG, "deleteRendezVous: id=" + id + " | deleted=" + deleted);
        return deleted;
    }

    public boolean patientHasRendezVous(int patientId, String date) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM rendezvous WHERE patient_id=? AND date LIKE ?",
                new String[]{String.valueOf(patientId), date + "%"});
        boolean hasRdv = false;
        if (cursor != null) {
            if (cursor.moveToFirst()) hasRdv = cursor.getInt(0) > 0;
            cursor.close();
        }
        Log.d(TAG, "patientHasRendezVous: patientId=" + patientId + " | date=" + date + " | hasRdv=" + hasRdv);
        return hasRdv;
    }

    public int getRendezVousCountByDate(String date) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM rendezvous WHERE date LIKE ?", new String[]{date + "%"});
        int count = 0;
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                count = cursor.getInt(0);
            }
            cursor.close();
        }
        Log.d(TAG, "getRendezVousCountByDate: date=" + date + " | count=" + count);
        return count;
    }

    // Retourne les rendez-vous filtrés par nom ou date
    public ArrayList<RendezVous> searchRendezVous(String query) {
        ArrayList<RendezVous> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Recherche par nom de patient ou date (LIKE pour correspondance partielle)
        Cursor cursor = db.rawQuery(
                "SELECT r.id, r.patient_id, r.medecin_id, r.date, r.statut, r.rappel, p.nom, p.prenom " +
                        "FROM rendezvous r " +
                        "INNER JOIN patient p ON r.patient_id = p.id " +
                        "WHERE p.nom || ' ' || p.prenom LIKE ? OR r.date LIKE ? " +
                        "ORDER BY r.date ASC",
                new String[]{"%" + query + "%", "%" + query + "%"}
        );

        if (cursor != null && cursor.moveToFirst()) {
            do {
                RendezVous rdv = new RendezVous();
                rdv.setId(cursor.getInt(cursor.getColumnIndexOrThrow("id")));
                rdv.setPatientId(cursor.getInt(cursor.getColumnIndexOrThrow("patient_id")));
                rdv.setMedecinId(cursor.getInt(cursor.getColumnIndexOrThrow("medecin_id")));
                rdv.setDate(cursor.getString(cursor.getColumnIndexOrThrow("date")));
                rdv.setStatut(cursor.getString(cursor.getColumnIndexOrThrow("statut")));
                rdv.setRappel(cursor.getInt(cursor.getColumnIndexOrThrow("rappel")));
                rdv.setPatientName(cursor.getString(cursor.getColumnIndexOrThrow("nom")) + " " +
                        cursor.getString(cursor.getColumnIndexOrThrow("prenom")));
                list.add(rdv);
            } while (cursor.moveToNext());
            cursor.close();
        }

        return list;
    }


    public ArrayList<RendezVous> getRendezVousByDate(String date) {
        ArrayList<RendezVous> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM rendezvous WHERE date LIKE ?", new String[]{date + "%"});
        if (cursor != null && cursor.moveToFirst()) {
            do {
                RendezVous rdv = new RendezVous();
                rdv.setId(cursor.getInt(cursor.getColumnIndexOrThrow("id")));
                rdv.setPatientId(cursor.getInt(cursor.getColumnIndexOrThrow("patient_id")));
                rdv.setMedecinId(cursor.getInt(cursor.getColumnIndexOrThrow("medecin_id")));
                rdv.setDate(cursor.getString(cursor.getColumnIndexOrThrow("date")));
                rdv.setStatut(cursor.getString(cursor.getColumnIndexOrThrow("statut")));
                rdv.setRappel(cursor.getInt(cursor.getColumnIndexOrThrow("rappel")));
                rdv.setPatientName(getPatientNameById(rdv.getPatientId()));
                list.add(rdv);
            } while (cursor.moveToNext());
            cursor.close();
        }
        return list;
    }

    public String getPatientNameById(int patientId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT nom, prenom FROM patient WHERE id=?", new String[]{String.valueOf(patientId)});
        String name = "";
        if (cursor != null && cursor.moveToFirst()) {
            name = cursor.getString(cursor.getColumnIndexOrThrow("nom")) + " " +
                    cursor.getString(cursor.getColumnIndexOrThrow("prenom"));
            cursor.close();
        }
        return name;
    }



    public Cursor getAvailablePatients(String date) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM patient WHERE id NOT IN (SELECT patient_id FROM rendezvous WHERE date LIKE ?)",
                new String[]{date + "%"});
        Log.d(TAG, "getAvailablePatients: date=" + date + " | count=" + (cursor != null ? cursor.getCount() : 0));
        return cursor;
    }

    // ====================== STATISTIQUES ======================
    // ====================== STATISTIQUES ======================

    // Retourne le nombre total de patients
    public int getTotalPatients() {
        int total = 0;
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = this.getReadableDatabase();
            cursor = db.rawQuery("SELECT COUNT(*) FROM patient", null);
            if (cursor != null && cursor.moveToFirst()) {
                total = cursor.getInt(0);
            }
        } catch (Exception e) {
            e.printStackTrace(); // Log pour savoir ce qui pose problème
        } finally {
            if (cursor != null) cursor.close();
            if (db != null) db.close();
        }
        return total;
    }

    // Retourne le nombre total de rendez-vous
    public int getTotalRendezVous() {
        int total = 0;
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = this.getReadableDatabase();
            cursor = db.rawQuery("SELECT COUNT(*) FROM rendezvous", null);
            if (cursor != null && cursor.moveToFirst()) {
                total = cursor.getInt(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) cursor.close();
            if (db != null) db.close();
        }
        return total;
    }

    // Retourne le nombre total d'ordonnances
    public int getTotalOrdonnances() {
        int total = 0;
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = this.getReadableDatabase();
            cursor = db.rawQuery("SELECT COUNT(*) FROM ordonnance", null);
            if (cursor != null && cursor.moveToFirst()) {
                total = cursor.getInt(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) cursor.close();
            if (db != null) db.close();
        }
        return total;
    }



    // ====================== UTILITAIRES ======================
    public static String md5(String s) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
            byte[] array = md.digest(s.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : array) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (java.security.NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }
}
